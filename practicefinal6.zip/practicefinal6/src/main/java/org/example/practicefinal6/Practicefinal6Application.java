package org.example.practicefinal6;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Practicefinal6Application {

    public static void main(String[] args) {
        SpringApplication.run(Practicefinal6Application.class, args);
    }

}
