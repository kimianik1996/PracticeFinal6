package org.example.practicefinal6.controller;

import org.example.practicefinal6.model.Customer;
import org.example.practicefinal6.model.Projection;
import org.example.practicefinal6.service.CustomerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import java.util.List;

public class CustomerController {

    @Autowired
    private CustomerService customerService;

    @GetMapping("/")
    public String viewHomePage(Model model) {
        model.addAttribute("listCustomers", customerService.getAllCustomers());
        return "index";
    }

    @GetMapping("/showNewCustomerForm")
    public String showNewCustomerForm(Model model) {
        Customer customer = new Customer();
        model.addAttribute("customer", customer);
        return "new_customer";
    }

    @PostMapping("/saveCustomer")
    public String saveCustomer(@ModelAttribute("customer") Customer customer, Model model) {
        try {
            customerService.saveCustomer(customer);
        } catch (RuntimeException e) {
            model.addAttribute("errorMessage", "The record you are trying to add already exists. Choose a different customer number.");
            model.addAttribute("customer", customer);
            return "new_customer";
        }
        return "redirect:/";
    }

    @GetMapping("/showFormForUpdate/{id}")
    public String showFormForUpdate(@PathVariable(value = "id") long id, Model model) {
        Customer customer = customerService.getCustomerById(id);
        model.addAttribute("customer", customer);
        return "update_customer";
    }

    @PostMapping("/updateCustomer")
    public String updateCustomer(@ModelAttribute("customer") Customer customer) {
        customerService.updateCustomer(customer);
        return "redirect:/";
    }

    @GetMapping("/deleteCustomer/{id}")
    public String deleteCustomer(@PathVariable(value = "id") long id) {
        customerService.deleteCustomer(id);
        return "redirect:/";
    }

    @GetMapping("/projectedInvestment/{id}")
    public String projectedInvestment(@PathVariable(value = "id") long id, Model model) {
        Customer customer = customerService.getCustomerById(id);
        List<Projection> projections = customerService.calculateProjectedInvestment(customer);
        model.addAttribute("customer", customer);
        model.addAttribute("projections", projections);
        return "projected_investment";
    }
}
