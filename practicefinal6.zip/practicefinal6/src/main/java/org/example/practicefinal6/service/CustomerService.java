package org.example.practicefinal6.service;

import org.example.practicefinal6.model.Customer;
import org.example.practicefinal6.model.Projection;
import org.example.practicefinal6.repository.CustomerRepository;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.ArrayList;
import java.util.List;

public class CustomerService {
    @Autowired
    private CustomerRepository customerRepository;

    public List<Customer> getAllCustomers() {
        return customerRepository.findAll();
    }

    public Customer saveCustomer(Customer customer) {
        if (customerRepository.existsByCustomerNumber(customer.getCustomerNumber())) {
            throw new RuntimeException("Customer number already exists");
        }
        return customerRepository.save(customer);
    }

    public Customer updateCustomer(Customer customer) {
        return customerRepository.save(customer);
    }

    public void deleteCustomer(Long id) {
        customerRepository.deleteById(id);
    }

    public Customer getCustomerById(Long id) {
        return customerRepository.findById(id).orElse(null);
    }

    public List<Projection> calculateProjectedInvestment(Customer customer) {
        List<Projection> projections = new ArrayList<>();
        double rate = customer.getSavingsType().equals("Savings-Deluxe") ? 0.15 : 0.10;
        double initialDeposit = customer.getInitialDeposit();
        for (int year = 1; year <= customer.getNumberOfYears(); year++) {
            initialDeposit += initialDeposit * rate;
            projections.add(new Projection(year, initialDeposit));
        }
        return projections;
    }

}
