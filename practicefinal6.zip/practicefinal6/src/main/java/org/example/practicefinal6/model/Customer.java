package org.example.practicefinal6.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor

public class Customer {

    public Long getId() {
        return id;
    }

    public String getCustomerNumber() {
        return customerNumber;
    }

    public String getCustomerName() {
        return customerName;
    }

    public double getInitialDeposit() {
        return initialDeposit;
    }

    public int getNumberOfYears() {
        return numberOfYears;
    }

    public String getSavingsType() {
        return savingsType;
    }

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    public Long id;
    public String customerNumber;
    public String customerName;
    public double initialDeposit;
    public int numberOfYears;
    public String savingsType;





    public void setId(Long id) {
        this.id = id;
    }



    public void setCustomerNumber(String customerNumber) {
        this.customerNumber = customerNumber;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public void setInitialDeposit(double initialDeposit) {
        this.initialDeposit = initialDeposit;
    }

    public void setNumberOfYears(int numberOfYears) {
        this.numberOfYears = numberOfYears;
    }

    public void setSavingsType(String savingsType) {
        this.savingsType = savingsType;
    }




}
