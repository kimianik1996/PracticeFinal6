package org.example.practicefinal6.model;

public class Projection {
    private int year;
    private double endingValue;

    public Projection(int year, double endingValue) {
        this.year = year;
        this.endingValue = endingValue;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public double getEndingValue() {
        return endingValue;
    }

    public void setEndingValue(double endingValue) {
        this.endingValue = endingValue;
    }
}
