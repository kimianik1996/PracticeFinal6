package org.example.practicefinal6;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Practicefinal6ApplicationTests {

    @Test
    void contextLoads() {
    }

}
